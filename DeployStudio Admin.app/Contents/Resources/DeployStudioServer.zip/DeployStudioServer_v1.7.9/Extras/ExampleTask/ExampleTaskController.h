//
//  ExampleTaskController.h
//  ExampleTask.bundle
//
//  Created by The DeployStudio Team on Tue Apr 22 2014.
//  Copyright 2014 The DeployStudio Team. All rights reserved.
//

#import "DSPluginProtocol.h"

#define kDSTUDIO_WORKFLOW_TASK_IDENTIFIER        @"example"

#define kDSTUDIO_TASK_KEY_POLICY_BANNER_CONTENT  @"policy_banner_content"

@interface ExampleTaskController : NSObject <DSPluginProtocol>
{
    NSString                *pluginName;
    NSString                *pluginTooltip;
    NSString                *pluginDescription;
    
    NSImage                 *icon32Image;
    NSImage                 *icon128Image;
    
    IBOutlet NSView         *adminView;
    IBOutlet NSPopUpButton  *adminTargetTypePopUpButton;
    IBOutlet NSComboBox     *adminTargetComboBox;
	IBOutlet NSTextView	    *adminPolicyBannerTextView;
	IBOutlet NSButton	    *adminAutomateButton;
    
    NSMutableDictionary     *adminConfig;
    
    IBOutlet NSView         *runtimeView;
    IBOutlet NSPopUpButton  *runtimeTargetPopUpButton;
    IBOutlet NSTextView	    *runtimePolicyBannerTextView;
	
    BOOL                    runtimeAutomate;
       
    id <DSCryptoServicesProtocol>    dSCryptoServices;
    id <DSHostServicesProtocol>      dSHostServices;
    id <DSServerClientProtocol>      dSServerClient;
    id <DSRuntimeServicesProtocol>   dSRuntimeServices;
    id <DSPreferencesProtocol>       dSPreferences;
}

// General information
- (double)                  pluginVersion;

- (NSString*)               identifier;
- (NSImage*)                icon32x32;
- (NSImage*)                icon128x128;

- (NSString*)               name;
- (NSString*)               tooltip;
- (NSString*)               description;

// DeployStudio Admin methods
- (NSView*)                 adminView;
- (NSResponder*)            adminFirstResponder;
- (IBAction)                adminNotifyChangesAction:(id)sender;
- (IBAction)                adminTargetTypeAction:(id)sender;
- (void)                    updateAdminViewWithConfig:(NSMutableDictionary*)aConfig
                                           ofWorkflow:(NSDictionary*)theEditedWorkflow
                                        targetVolumes:(NSArray*)theTargetVolumes;
- (NSMutableDictionary*)    getAdminViewConfig;

// DeployStudio Runtime methods
- (NSView*)                 runtimeView;
- (NSResponder*)            runtimeFirstResponder;
- (NSString*)               runtimeFilteredTarget:(NSString*)aTarget;
- (void)                    updateRuntimeViewWithConfig:(NSMutableDictionary*)aConfig;
- (void)                    revert;
- (void)                    proceed;
- (void)                    skip;

@end
