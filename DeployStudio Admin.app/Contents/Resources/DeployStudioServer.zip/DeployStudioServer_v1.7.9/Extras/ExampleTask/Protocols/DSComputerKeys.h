//
//  DSComputerKeys.h
//  DSCore.framework
//
//  Created by The DeployStudio Team on Sun Feb 9 2014.
//  Copyright 2014 The DeployStudio Team. All rights reserved.
//

// keys
#define kDSTUDIO_COMPUTER_KEY_EDITING_CONTEXT                   @"dstudio-editing-context"

#define kDSTUDIO_COMPUTER_KEY_PRIMARY_KEY						@"dstudio-host-primary-key"

#define kDSTUDIO_COMPUTER_KEY_MAC_ADDRESS						@"dstudio-mac-addr"

#define kDSTUDIO_COMPUTER_KEY_CLEAR_TEXT_PASSWORDS				@"dstudio-clear-text-passwords"

#define kDSTUDIO_COMPUTER_KEY_COMPUTER_TYPE						@"dstudio-host-type"

#define kDSTUDIO_COMPUTER_KEY_MODEL_IDENTIFIER                  @"dstudio-host-model-identifier"
#define kDSTUDIO_COMPUTER_KEY_SERIAL_NUMBER                     @"dstudio-host-serial-number"

#define kDSTUDIO_COMPUTER_KEY_DISABLED							@"dstudio-disabled"
#define kDSTUDIO_COMPUTER_KEY_COMPUTER_NAME						@"cn"
#define kDSTUDIO_COMPUTER_KEY_HOSTNAME							@"dstudio-hostname"
#define kDSTUDIO_COMPUTER_KEY_BOOTCAMP_WINDOWS_COMPUTER_NAME	@"dstudio-bootcamp-windows-computer-name"
#define kDSTUDIO_COMPUTER_KEY_BOOTCAMP_WINDOWS_PRODUCT_KEY      @"dstudio-bootcamp-windows-product-key"
#define kDSTUDIO_COMPUTER_KEY_CM_COMPUTER_GROUPS				@"dstudio-clientmanagement-computer-groups"
#define kDSTUDIO_COMPUTER_KEY_SERVER_LICENSE					@"dstudio-serial-number"
#define kDSTUDIO_COMPUTER_KEY_XSAN_LICENSE						@"dstudio-xsan-license"

#define kDSTUDIO_COMPUTER_KEY_ARD_IGNORE_EMPTY_FIELDS			@"dstudio-host-ard-ignore-empty-fields"
#define kDSTUDIO_COMPUTER_KEY_ARD_FIELD_1						@"dstudio-host-ard-field-1"
#define kDSTUDIO_COMPUTER_KEY_ARD_FIELD_2						@"dstudio-host-ard-field-2"
#define kDSTUDIO_COMPUTER_KEY_ARD_FIELD_3						@"dstudio-host-ard-field-3"
#define kDSTUDIO_COMPUTER_KEY_ARD_FIELD_4						@"dstudio-host-ard-field-4"

#define kDSTUDIO_COMPUTER_KEY_NETWORK_NEW_LOCATION				@"dstudio-host-new-network-location"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_LOCATION_NAME				@"dstudio-host-location"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_FIRST_INTERFACE			@"dstudio-host-first-interface"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_INTERFACES				@"dstudio-host-interfaces"
#define kDSTUDIO_COMPUTER_KEY_DELETE_OTHER_LOCATIONS			@"dstudio-host-delete-other-locations"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_INTERFACE					@"dstudio-host-interface"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_IP_ADDRESS				@"dstudio-host-ip"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_USE_DHCP_VALUES			@"dstudio-host-use-dhcp-values"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SUBNET					@"dstudio-subnet-mask"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SUBNET_FROM_DHCP			@"dstudio-host-subnet-from-dhcp"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_ROUTER_IP_ADDRESS			@"dstudio-router-ip"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_DNS_IP_ADDRESSES			@"dstudio-dns-ips"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SEARCH_DOMAINS			@"dstudio-search-domains"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_AIRPORT				@"dstudio-host-airport"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_AIRPORT_NAME				@"dstudio-host-airport-name"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_AIRPORT_PASSWORD			@"dstudio-host-airport-password"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_FTP_PROXY				@"dstudio-host-ftp-proxy"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_FTP_PROXY_SERVER		@"dstudio-host-ftp-proxy-server"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_FTP_PROXY_PORT		@"dstudio-host-ftp-proxy-port"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_HTTP_PROXY			@"dstudio-host-http-proxy"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_HTTP_PROXY_SERVER		@"dstudio-host-http-proxy-server"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_HTTP_PROXY_PORT		@"dstudio-host-http-proxy-port"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_HTTPS_PROXY			@"dstudio-host-https-proxy"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_HTTPS_PROXY_SERVER	@"dstudio-host-https-proxy-server"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_HTTPS_PROXY_PORT		@"dstudio-host-https-proxy-port"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_AUTO_DISCOVERY_PROXY	@"dstudio-host-auto-discovery-proxy"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_AUTO_CONFIG_PROXY		@"dstudio-host-auto-config-proxy"
#define kDSTUDIO_COMPUTER_KEY_NETWORK_SET_AUTO_CONFIG_PROXY_URL	@"dstudio-host-auto-config-proxy-url"

#define kDSTUDIO_COMPUTER_KEY_USERS								@"dstudio-users"
#define kDSTUDIO_COMPUTER_KEY_USER_NAME							@"dstudio-user-name"
#define kDSTUDIO_COMPUTER_KEY_USER_SHORTNAME					@"dstudio-user-shortname"
#define kDSTUDIO_COMPUTER_KEY_USER_PASSWORD						@"dstudio-user-password"
#define kDSTUDIO_COMPUTER_KEY_USER_SET_ADMIN					@"dstudio-user-admin-status"
#define kDSTUDIO_COMPUTER_KEY_USER_SET_HIDDEN					@"dstudio-user-hidden-status"
#define kDSTUDIO_COMPUTER_KEY_USER_LOCALE						@"dstudio-user-locale"

#define kDSTUDIO_COMPUTER_KEY_CUSTOM_PROPERTIES					@"dstudio-custom-properties"
#define kDSTUDIO_COMPUTER_KEY_CUSTOM_PROPERTY_KEY     			@"dstudio-custom-property-key"
#define kDSTUDIO_COMPUTER_KEY_CUSTOM_PROPERTY_LABEL				@"dstudio-custom-property-label"
#define kDSTUDIO_COMPUTER_KEY_CUSTOM_PROPERTY_VALUE				@"dstudio-custom-property-value"

//#define kDSTUDIO_COMPUTER_KEY_INHERIT_AUTOMATION_SETTINGS		@"dstudio-inherit-automation"
#define kDSTUDIO_COMPUTER_KEY_AUTO_STARTED_WORKFLOW				@"dstudio-auto-started-workflow"
#define kDSTUDIO_COMPUTER_KEY_AUTO_STARTED_WORKFLOW_SCRIPT		@"dstudio-auto-started-workflow-script"
#define kDSTUDIO_COMPUTER_KEY_AUTO_RESET_WORKFLOW				@"dstudio-auto-reset-workflow"
#define kDSTUDIO_COMPUTER_KEY_AUTO_DISABLE_HOST					@"dstudio-auto-disable"
#define kDSTUDIO_COMPUTER_KEY_HIDE_MAIN_WINDOW					@"dstudio-hide-mainwindow"

#define kDSTUDIO_COMPUTER_KEY_LAST_WORKFLOW						@"dstudio-last-workflow"
#define kDSTUDIO_COMPUTER_KEY_LAST_WORKFLOW_DATE				@"dstudio-last-workflow-execution-date"
#define kDSTUDIO_COMPUTER_KEY_LAST_WORKFLOW_DURATION			@"dstudio-last-workflow-duration"
#define kDSTUDIO_COMPUTER_KEY_LAST_WORKFLOW_STATUS				@"dstudio-last-workflow-status"

#define kDSTUDIO_GROUP_KEY_NAME									@"dstudio-group-name"
#define kDSTUDIO_GROUP_KEY_DEFAULT_GROUP_NAME					@"dstudio-group-default-group-name"
#define kDSTUDIO_GROUP_KEY_HOSTNANE_INDEX_LENGTH				@"dstudio-group-hosname-index-length"
#define kDSTUDIO_GROUP_KEY_HOSTNANE_INDEX_FIRST_VALUE			@"dstudio-group-hosname-index-first-value"
