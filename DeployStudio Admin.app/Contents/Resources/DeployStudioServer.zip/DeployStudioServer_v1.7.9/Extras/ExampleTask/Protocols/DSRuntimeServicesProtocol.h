//
//  DSRuntimeServicesProtocol.h
//  DSCore.framework
//
//  Created by The DeployStudio Team on Mon Jun 18 2012.
//  Copyright 2014 The DeployStudio Team. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol DSRuntimeServicesProtocol <NSObject>

// Workflow control buttons
- (void)        setReloadButtonEnabled:(BOOL)aStatus;
- (void)        setBackButtonEnabled:(BOOL)aStatus;
- (void)        setSkipButtonEnabled:(BOOL)aStatus;
- (void)        setProceedButtonEnabled:(BOOL)aStatus;

- (BOOL)        proceedButtonEnabled;

- (void)        syncButtonsStatus;

// Status pane
- (void)        resetStatusPane;
- (void)        setStatusMessage:(NSString*)aMessage;

- (void)        animateCurrentTask;

- (void)        resetCurrentTaskProgression;
- (void)        setCurrentTaskProgressbarWithMaxValue:(unsigned long long)aMaxValue;
- (void)        setCurrentTaskProgressbarWithMaxValue:(unsigned long long)aMaxValue
                                   expectedObjectSize:(unsigned long long)anExpectedSize;
- (void)        setCurrentTaskProgressbarWithMaxValue:(unsigned long long)aMaxValue
                                    inspectedFilePath:(NSString*)anInspectedFilePath
                                     expectedFileSize:(unsigned long long)anExpectedSize;
- (void)        fillCurrentTaskProgression;

// Workflow execution context information
- (void)        setMonitoredDevice:(NSString*)aMonitoredDevice;
- (NSString*)   monitoredDevice;

- (void)        setLastSelectedTarget:(NSString*)aTarget;
- (NSString*)   lastSelectedTarget;

- (void)        setLastRestoredVolume:(NSString*)aRestoredVolume;
- (NSString*)   lastRestoredVolume;

- (void)        setLastRestoredDevice:(NSString*)aRestoredDevice;
- (NSString*)   lastRestoredDevice;

- (void)        setBootDevice:(NSString*)aBootDevice;
- (NSString*)   bootDevice;

- (void)        setStartupVolume:(NSString*)aStartupVolume;
- (NSString*)   startupVolume;

- (void)        setNextBootMode:(NSString*)aNextBootMode;
- (NSString*)   nextBootMode;

- (void)        setNetBootContext:(BOOL)isNetBootContext;
- (BOOL)        netBootContext;

// Useful repository methods
- (BOOL)        isLocalRepository;

- (NSString*)   pathToWorkInProgressRepository;
- (NSString*)   pathToHFSDiskImagesRepository;
- (NSString*)   pathToFATDiskImagesRepository;
- (NSString*)   pathToNTFSDiskImagesRepository;
- (NSArray*)    listOfMacDiskImagesWithKeywords:(NSArray*)theKeywords
                                      forGroups:(NSArray*)theGroups
                                includeDisabled:(BOOL)includeDisabled;
- (NSDictionary*)       diskImageInfos:(NSString*)aDiskImageName;
- (unsigned long long)  diskImageSize:(NSString*)aDiskImageName;
- (NSString*)           diskImageFileSystem:(NSString*)aDiskImageName;
- (NSString*)           diskImagePath:(NSString*)aDiskImageName;

- (NSString*)   pathToPackagesRepository;
- (NSArray*)    listOfPackagesWithKeywords:(NSArray*)theKeywords forGroups:(NSArray*)theGroups includeDisabled:(BOOL)includeDisabled;

- (NSString*)   pathToConfigurationProfilesRepository;

- (NSString*)   pathToScriptsRepository;
- (NSString*)   scriptPathWithFile:(NSString*)aFileName;

- (NSString*)   pathToFilesRepository;
- (NSArray*)    listOfFilesWithKeywords:(NSArray*)theKeywords forGroups:(NSArray*)theGroups;

- (NSMutableArray*) directoryContentsAtPath:(NSString*)aPath;

// Shell calls
- (BOOL)        installDSFinalizeResourcesOnVolume:(NSString*)aVolume;

- (NSArray*)    argumentsWithString:(NSString*)argumentsString;

- (BOOL)        run:(NSString*)aCommandPath withArguments:(NSArray*)theArguments
                asRoot:(BOOL)runAsRoot logCommand:(BOOL)logCommand keepLogs:(BOOL)keepLogs;

- (NSString*)   parseKey:(char*)aKey vIn:(char*)aVIn vOut:(char*)aVOut
                inOutputOfCommand:(NSString*)aCommandPath withArguments:(NSArray*)theArguments
                trimLines:(BOOL)trimLines asRoot:(BOOL)runAsRoot keepLogs:(BOOL)keepLogs;

- (NSString*)   outputOfCommand:(NSString*)aCommandPath withArguments:(NSArray*)theArguments asRoot:(BOOL)runAsRoot;
- (NSString*)   fullOutputOfCommand:(NSString*)aCommandPath withArguments:(NSArray*)theArguments asRoot:(BOOL)runAsRoot;

@end
