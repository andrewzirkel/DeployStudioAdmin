//
//  DSPreferencesProtocol.h
//  DSCore.framework
//
//  Created by The DeployStudio Team on Mon Jun 18 2012.
//  Copyright 2014 The DeployStudio Team. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol DSPreferencesProtocol <NSObject>

- (NSArray*)  bundleLanguagesNames;
- (NSString*) bundleLanguageCodeForName:(NSString*)aName;
- (NSString*) bundleLanguageNameForCode:(NSString*)aCode;

- (NSString*) defaultLanguageName;
- (NSString*) defaultRegionName;
- (NSString*) defaultKeyboardLayoutName;

- (NSArray*)  languagesNames;
- (NSString*) languageCodeForName:(NSString*)aName;
- (NSString*) languageNameForCode:(NSString*)aCode;

- (NSArray*)  regionsNames;
- (NSString*) regionCodeForName:(NSString*)aName;

- (NSArray*)      keyboardLayoutsNames;
- (NSDictionary*) keyboardLayoutForName:(NSString*)aName;

@end
