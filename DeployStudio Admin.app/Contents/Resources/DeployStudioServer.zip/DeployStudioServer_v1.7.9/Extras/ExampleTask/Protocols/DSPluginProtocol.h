//
//  DSPluginProtocol.h
//  DSCore.framework
//
//  Created by The DeployStudio Team on Wed Dec 7 2011.
//  Copyright 2014 The DeployStudio Team. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DSComputerKeys.h"
#import "DSCryptoServicesProtocol.h"
#import "DSHostServicesProtocol.h"
#import "DSServerClientProtocol.h"
#import "DSRuntimeServicesProtocol.h"
#import "DSPreferencesProtocol.h"

#define DS_PLUGIN_PROTOCOL_VERSION  1.0

// Default Macros
#define mDSTUDIO_LOC(x) [[NSBundle bundleForClass:[self class]] localizedStringForKey:x value:nil table:@"Localization"]

// Default constants
#define kDSTUDIO_TASK_ARCH_MAC_PPC                      @"ppc"
#define kDSTUDIO_TASK_ARCH_MAC_INTEL                    @"i386"
#define kDSTUDIO_TASK_ARCH_PC                           @"PC"

// Default task keys
#define kDSTUDIO_TASK_KEY_TARGET_TYPE                   @"targettype"
#define kDSTUDIO_TASK_KEY_TARGET_NAME                   @"targetname"
#define kDSTUDIO_TASK_KEY_AUTOMATE                      @"automate"
#define kDSTUDIO_TASK_KEY_REQUIRED                      @"required"
#define kDSTUDIO_TASK_KEY_HOST_CONFIG                   @"_hostconfig"   // computer database record (runtime)


// Default target types
#define kDSTUDIO_TASK_TARGET_TYPE_FIXED                 @"fixed"
#define kDSTUDIO_TASK_TARGET_TYPE_LAST_SELECTED         @"lastselectedtarget"
#define kDSTUDIO_TASK_TARGET_TYPE_LAST_RESTORED         @"lastrestoredtarget"
#define kDSTUDIO_TASK_TARGET_TYPE_FIRST_DISK            @"firstdisk"

// Default notifications
#define kDSTUDIO_TASK_EDITED_NOTIFICATION               @"kDSTUDIO_TASK_EDITED_NOTIFICATION"

#define kDSTUDIO_TASK_REVERT_NOTIFICATION               @"kDSTUDIO_TASK_REVERT_NOTIFICATION"
#define kDSTUDIO_TASK_COMPLETED_NOTIFICATION            @"kDSTUDIO_TASK_COMPLETED_NOTIFICATION"
#define kDSTUDIO_TASK_FAILED_NOTIFICATION               @"kDSTUDIO_TASK_FAILED_NOTIFICATION"

@protocol DSPluginProtocol <NSObject>

- (double)                  pluginVersion;

- (NSString*)               identifier;
- (NSImage*)                icon32x32;
- (NSImage*)                icon128x128;

- (NSString*)               name;
- (NSString*)               tooltip;
- (NSString*)               description;

- (NSView*)                 adminView;
- (NSResponder*)            adminFirstResponder;
- (void)                    updateAdminViewWithConfig:(NSMutableDictionary*)aConfig 
                                           ofWorkflow:(NSDictionary*)theEditedWorkflow 
                                        targetVolumes:(NSArray*)theTargetVolumes;
- (NSMutableDictionary*)    getAdminViewConfig;

- (NSView*)                 runtimeView;
- (NSResponder*)            runtimeFirstResponder;
- (void)                    updateRuntimeViewWithConfig:(NSMutableDictionary*)aConfig;
- (void)                    proceed;
- (void)                    skip;
- (void)                    revert;

@property (atomic, strong)  id <DSCryptoServicesProtocol>    dSCryptoServices;
@property (atomic, strong)  id <DSHostServicesProtocol>      dSHostServices;
@property (atomic, strong)  id <DSServerClientProtocol>      dSServerClient;
@property (atomic, strong)  id <DSRuntimeServicesProtocol>   dSRuntimeServices;
@property (atomic, strong)  id <DSPreferencesProtocol>       dSPreferences;

@end
