//
//  DSHostServicesProtocol.h
//  DSCore.framework
//
//  Created by The DeployStudio Team on Wed Feb 8 2012.
//  Copyright 2014 The DeployStudio Team. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol DSHostServicesProtocol <NSObject>

+ (NSString*) filterSerialNumber:(NSString*)aSerialNumber;
+ (NSString*) filterMACAddress:(NSString*)aMACAddress;
+ (NSString*) filterASCIIName:(NSString*)aName deleteSpaces:(BOOL)deleteSpaces;
+ (NSString*) filterFirmwarePassword:(NSString*)aPassword;
+ (NSString*) filterHostName:(NSString*)aHostName;
+ (NSString*) filterHostName:(NSString*)aHostName trim:(BOOL)doTrim;
+ (NSString*) filterLocalHostName:(NSString*)aLocalHostName;
+ (NSString*) filterLocalHostName:(NSString*)aLocalHostName trim:(BOOL)doTrim;
+ (NSString*) filterListOfHostNames:(NSString*)theHostsNames trim:(BOOL)doTrim;
+ (NSString*) filterADDomainName:(NSString*)aDomainName trim:(BOOL)doTrim;
+ (NSString*) filterBootCampWindowsComputerName:(NSString*)aBootCampWindowsComputerName suffixLength:(int)suffixLength;
+ (NSString*) filterBootCampWindowsComputerName:(NSString*)aBootCampWindowsName suffixLength:(int)suffixLength trim:(BOOL)doTrim;
+ (NSString*) filterBootCampWindowsProductKey:(NSString*)aBootCampWindowsProductKey;
+ (NSString*) filterSearchDomainNames:(NSString*)theSearchDomainNames;
+ (NSString*) filterSearchDomainNames:(NSString*)theSearchDomainNames trim:(BOOL)doTrim;
+ (NSString*) finalizeIPAddress:(NSString*)aIPAddress asScope:(BOOL)isScopeAddress;
+ (NSString*) filterIPAddress:(NSString*)aIPAddress;
+ (NSString*) filterIPAddress:(NSString*)aIPAddress trim:(BOOL)doTrim;
+ (BOOL)      isIPAddress:(NSString*)aIPAddress;
+ (NSString*) filterPortNumber:(NSString*)aPortNumber;
+ (NSString*) filterShortName:(NSString*)aShortName;
+ (NSString*) filterShortName:(NSString*)aShortName trim:(BOOL)doTrim;
+ (NSString*) filterActiveDirectoryListOfGroups:(NSString*)theActiveDirectoryGroups;

+ (NSString*) filterHFSVolumeName:(NSString*)aVolumeName;
+ (NSString*) filterHFSVolumeName:(NSString*)aVolumeName doTrim:(BOOL)doTrim;
+ (NSString*) filterFATVolumeName:(NSString*)aVolumeName;
+ (NSString*) filterFATVolumeName:(NSString*)aVolumeName doTrim:(BOOL)doTrim;

+ (NSString*) filterCustomPropertyKey:(NSString*)aCustomPropertyKey;
+ (NSString*) filterCustomPropertyKey:(NSString*)aCustomPropertyKey doTrim:(BOOL)doTrim;

+ (NSString*) filenameWithKey:(NSString*)aKey;

+ (void) updateNetworkConfigurationComputerModelInVolume:(NSString*)aVolumeName;
+ (BOOL) addStaticNetworkLocation:(NSString*)locationName
				   withInterfaces:(NSDictionary*)interfaces
                       setDefault:(BOOL)isDefault 
                     deleteOthers:(BOOL)deleteOthers 
                         inVolume:(NSString*)aVolume;

+ (NSString*) hostIPWithName:(NSString*)hostName retries:(int)numberOfRetries;
+ (NSString*) hostnameWithIPAddress:(NSString*)hostIPAddress retries:(int)numberOfRetries;
+ (NSDictionary*) hostNetworkInterfaceConfig:(NSString*)aInterface;
+ (NSString*) hostRouterForInterface:(NSString*)anInterface withIPAddress:(NSString*)anIPAddress;
+ (NSString*) hostAssignedIP;
- (NSString*) hostAssignedHostname;
+ (NSString*) hostAssignedRouter;
+ (NSString*) hostAssignedDNS;
+ (NSString*) hostAssignedDomainName;
+ (NSString*) hostEthernetInterfaceSpeed;

+ (NSString*) hostArchitecture;
+ (NSString*) hostModelIdentifier;
+ (NSString*) hostSerialNumber;

+ (BOOL) hostHasSuperdrive;
+ (BOOL) hostAssessmentsCheckEnabled;

- (NSString*) hostIdentifier;
- (NSString*) hostFilteredIdentifier;

- (NSString*) hostBootDevice;
- (NSString*) hostBootDisk;
+ (unsigned long long) hostDiskSize:(NSString*)aDisk;
+ (unsigned long long) hostDeviceSize:(NSString*)aDiskDevice;

+ (NSString*) hostVolumeName:(NSString*)aDevice;
+ (NSString*) hostDeviceNodePath:(NSString*)aVolumePath;
+ (NSString*) hostPhysicalDiskIdentifier:(NSString*)aVolumePath;
+ (NSString*) hostDiskIdentifier:(NSString*)aVolumePath;
+ (NSString*) hostNextDeviceIdentifier:(NSString*)aDeviceIdentifier;
+ (NSString*) hostRecoveryDeviceIdentifierForDeviceIdentifier:(NSString*)aDeviceIdentifier;
+ (BOOL) hostIsSoftRAIDDevice:(NSString*)aDevice;
+ (NSString*) hostRAIDVolumeName:(NSString*)aDevice;
+ (NSMutableArray*) hostListOfVolumes:(BOOL)includeBootVolume;
+ (NSMutableArray*) hostListOfSystemVolumes;
+ (NSMutableArray*) hostListOfScratchVolumesForSource:(NSString*)aSourceVolumePath;
+ (NSMutableArray*) hostListOfInternalSolidStateDrives;
+ (NSMutableArray*) hostListOfInternalHardDrives;
+ (NSMutableArray*) hostListOfDisks;
+ (NSMutableArray*) hostListOfUnknownFileSystems;
+ (NSString*) hostFirstAvailableDisk;
+ (NSDictionary*) hostListOfNetworkInterfacesDisplayName;
+ (NSDictionary*) hostListOfActiveNetworkInterfaces;
+ (NSArray*) hostListOfActiveIPAddresses;

+ (BOOL) isReachable:(NSString*)aHost atPort:(int)aPort retries:(int)numberOfRetries;

+ (NSString*) systemVersionForVolume:(NSString*)aVolumeName;
+ (NSString*) hostSystemVersion;
+ (int) systemMajorVersionForVolume:(NSString*)aVolumeName;
+ (int) hostSystemMajorVersion;
+ (int) systemMinorVersionForVolume:(NSString*)aVolumeName;
+ (int) hostSystemMinorVersion;
+ (double) hostSystemKUnitSize;

@end
