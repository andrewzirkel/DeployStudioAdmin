//
//  DSCryptoServicesProtocol.h
//  DSCore.framework
//
//  Created by The DeployStudio Team on Wed Jan 25 2012.
//  Copyright 2014 The DeployStudio Team. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol DSCryptoServicesProtocol <NSObject>

- (NSString*) cipher:(NSString*)aValue;
- (NSString*) decipher:(NSString*)aCipheredValue;

- (NSString*) xorAndHexFormat:(NSString*)aValue;

@end
