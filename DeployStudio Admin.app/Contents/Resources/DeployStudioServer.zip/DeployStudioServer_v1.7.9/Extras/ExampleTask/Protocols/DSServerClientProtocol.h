//
//  DSServerClientProtocol.h
//  DSCore.framework
//
//  Created by The DeployStudio Team on Wed Jan 25 2012.
//  Copyright 2014 The DeployStudio Team. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol DSServerClientProtocol <NSObject>

- (NSDictionary*) valueForURI:(NSString*)aURI error:(int*)errorRef;
- (void) setValue:(NSDictionary*)aValue forURI:(NSString*)aURI error:(int*)errorRef;

- (NSArray*) runtimeGroups;
- (NSArray*) runtimeMatchedGroups;

+ (NSString*) stringByAddingPercentEscapes:(NSString*)aString;

@end
