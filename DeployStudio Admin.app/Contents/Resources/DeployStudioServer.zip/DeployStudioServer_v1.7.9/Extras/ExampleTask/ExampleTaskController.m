//
//  ExampleTaskController.m
//  ExampleTask.bundle
//
//  Created by The DeployStudio Team on Tue Apr 22 2014.
//  Copyright 2014 The DeployStudio Team. All rights reserved.
//

#import "ExampleTaskController.h"

@implementation ExampleTaskController

@synthesize dSCryptoServices;
@synthesize dSHostServices;
@synthesize dSServerClient;
@synthesize dSRuntimeServices;
@synthesize dSPreferences;

- (id) init 
{
    if([super init] != nil)
    {
        [NSBundle loadNibNamed:@"ExampleTask" owner:self];

        pluginName        = [mDSTUDIO_LOC(@"TASK_TITLE") retain];
        pluginTooltip     = [mDSTUDIO_LOC(@"TASK_TOOLTIP") retain];
        pluginDescription = [mDSTUDIO_LOC(@"TASK_DESCRIPTION") retain];
        icon32Image       = [[NSImage alloc] initWithContentsOfFile:[[NSBundle bundleForClass:[self class]] pathForImageResource:@"Icon32"]];
        icon128Image      = [[NSImage alloc] initWithContentsOfFile:[[NSBundle bundleForClass:[self class]] pathForImageResource:@"Icon128"]];
        
        adminConfig             = nil;

        dSCryptoServices        = nil;
        dSHostServices          = nil;
        dSServerClient          = nil;
        dSRuntimeServices       = nil;
        dSPreferences           = nil;

        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(textDidChange:) 
                                                     name:NSControlTextDidChangeNotification 
                                                   object:nil];
    }
    
    return self;
}

- (void) dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];

    [pluginName             release];
    [pluginTooltip          release];
    [pluginDescription      release];
    [icon32Image            release];
    [icon128Image           release];

    [adminConfig            release];

    [dSCryptoServices       release];
    [dSHostServices         release];
    [dSServerClient         release];
    [dSRuntimeServices      release];
    [dSPreferences          release];
    
    [super dealloc];
}

- (double) pluginVersion
{
    return DS_PLUGIN_PROTOCOL_VERSION;
}

- (NSString*) identifier
{
    return kDSTUDIO_WORKFLOW_TASK_IDENTIFIER;
}

- (NSImage*) icon32x32
{
    return icon32Image;
}

- (NSImage*) icon128x128
{
    return icon128Image;
}

- (NSString*) name
{
    return pluginName;
}

- (NSString*) tooltip
{
    return pluginTooltip;
}

- (NSString*) description
{
    return pluginDescription;    
}

- (NSView*) adminView
{
    return adminView;
}

- (NSResponder*) adminFirstResponder
{
    return adminTargetComboBox;
}

- (IBAction) adminNotifyChangesAction:(id)sender
{
	[[NSNotificationCenter defaultCenter] postNotificationName:kDSTUDIO_TASK_EDITED_NOTIFICATION object:self userInfo:nil];
}

- (void) textDidChange:(NSNotification*)aNotification
{
	if([aNotification object] == adminPolicyBannerTextView)
        [self adminNotifyChangesAction:nil];
}

- (IBAction) adminTargetTypeAction:(id)sender
{
    [adminTargetComboBox validateEditing];
    [adminTargetComboBox setHidden:([adminTargetTypePopUpButton indexOfSelectedItem] > 0)];
	
	[self adminNotifyChangesAction:nil];
}

- (void) updateAdminViewWithConfig:(NSMutableDictionary*)aConfig 
                        ofWorkflow:(NSDictionary*)theEditedWorkflow 
                     targetVolumes:(NSArray*)theTargetVolumes
{
    [aConfig retain];
    [adminConfig release];
    adminConfig = aConfig;
    
    // target
    [adminTargetComboBox setObjectValue:@""];
    if([kDSTUDIO_TASK_TARGET_TYPE_LAST_RESTORED caseInsensitiveCompare:[adminConfig objectForKey:kDSTUDIO_TASK_KEY_TARGET_TYPE]] == NSOrderedSame)
        [adminTargetTypePopUpButton selectItemAtIndex:4];
    else if([kDSTUDIO_TASK_TARGET_TYPE_LAST_SELECTED caseInsensitiveCompare:[adminConfig objectForKey:kDSTUDIO_TASK_KEY_TARGET_TYPE]] == NSOrderedSame)
        [adminTargetTypePopUpButton selectItemAtIndex:3];
    else if([kDSTUDIO_TASK_TARGET_TYPE_FIXED caseInsensitiveCompare:[adminConfig objectForKey:kDSTUDIO_TASK_KEY_TARGET_TYPE]] == NSOrderedSame)
    {
        if(([adminConfig objectForKey:kDSTUDIO_TASK_KEY_TARGET_NAME] == nil) || ([[adminConfig objectForKey:kDSTUDIO_TASK_KEY_TARGET_NAME] length] < 1))
            [adminTargetTypePopUpButton selectItemAtIndex:2];
        else   
        {
            [adminTargetTypePopUpButton selectItemAtIndex:0];
            [adminTargetComboBox setObjectValue:[adminConfig objectForKey:kDSTUDIO_TASK_KEY_TARGET_NAME]];
        }    
    }
    else
        [adminTargetTypePopUpButton selectItemAtIndex:3];
 	[adminTargetComboBox setHidden:([adminTargetTypePopUpButton indexOfSelectedItem] > 0)];
	[adminTargetComboBox removeAllItems];
	if(theTargetVolumes != nil)
		[adminTargetComboBox addItemsWithObjectValues:theTargetVolumes];
    
    // get policy banner content
    if([adminConfig objectForKey:kDSTUDIO_TASK_KEY_POLICY_BANNER_CONTENT] != nil)
	{
		[adminPolicyBannerTextView replaceCharactersInRange:NSMakeRange(0, [[adminPolicyBannerTextView string] length])
                                                    withRTF:[adminConfig objectForKey:kDSTUDIO_TASK_KEY_POLICY_BANNER_CONTENT]];
	}
    else
        [adminPolicyBannerTextView setString:@""];
	
    [adminAutomateButton setState:
	 (([(NSString*)@"NO" caseInsensitiveCompare:[adminConfig valueForKey:kDSTUDIO_TASK_KEY_AUTOMATE]] == NSOrderedSame) ? NSOffState : NSOnState)];
}

- (NSMutableDictionary*) getAdminViewConfig
{
	BOOL automate = YES;
    
    switch ([adminTargetTypePopUpButton indexOfSelectedItem]) {
        case 2:
            [adminConfig setObject:kDSTUDIO_TASK_TARGET_TYPE_FIXED forKey:kDSTUDIO_TASK_KEY_TARGET_TYPE];
            [adminConfig setObject:@"" forKey:kDSTUDIO_TASK_KEY_TARGET_NAME];
            automate = NO;
            break;
        case 3:
            [adminConfig setObject:kDSTUDIO_TASK_TARGET_TYPE_LAST_SELECTED forKey:kDSTUDIO_TASK_KEY_TARGET_TYPE];
            break;
        case 4:
            [adminConfig setObject:kDSTUDIO_TASK_TARGET_TYPE_LAST_RESTORED forKey:kDSTUDIO_TASK_KEY_TARGET_TYPE];
            break;
        default:
            [adminConfig setObject:kDSTUDIO_TASK_TARGET_TYPE_FIXED forKey:kDSTUDIO_TASK_KEY_TARGET_TYPE];
            [adminConfig setObject:[adminTargetComboBox stringValue] forKey:kDSTUDIO_TASK_KEY_TARGET_NAME];
            automate = ([[adminTargetComboBox stringValue] length] > 0);
            break;
    }
    
    NSData *policyBannerContent = [adminPolicyBannerTextView RTFFromRange:NSMakeRange(0, [[adminPolicyBannerTextView string] length])];
	if((policyBannerContent == nil) || ([policyBannerContent length] < 1))
		[adminConfig removeObjectForKey:kDSTUDIO_TASK_KEY_POLICY_BANNER_CONTENT];
	else
		[adminConfig setObject:policyBannerContent forKey:kDSTUDIO_TASK_KEY_POLICY_BANNER_CONTENT];
	
    automate = automate && ([adminConfig objectForKey:kDSTUDIO_TASK_KEY_POLICY_BANNER_CONTENT] != nil);
	[adminConfig setObject:((automate == YES) ? @"YES" : @"NO") forKey:kDSTUDIO_TASK_KEY_AUTOMATE];

    return adminConfig;
}

- (NSView*) runtimeView
{
    return runtimeView;
}

- (NSResponder*) runtimeFirstResponder
{
    return runtimePolicyBannerTextView;
}

- (NSString*) runtimeFilteredTarget:(NSString*)aTarget
{
    if(aTarget != nil)
	{
		if([aTarget length] < 1)
			return nil;
		else if([aTarget hasPrefix:@"/Volumes/"] == YES)
		{
			if([[NSFileManager defaultManager] fileExistsAtPath:aTarget] == NO)
                return nil;
		}
		else if([aTarget hasPrefix:@"/dev/"] == YES)
		{
			if([[NSFileManager defaultManager] fileExistsAtPath:aTarget] == NO)
                return nil;
		}
		else if([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/Volumes/%@", aTarget]] == NO)
            return nil;
	}
    return aTarget;
}

- (void) updateRuntimeViewWithConfig:(NSMutableDictionary*)aConfig
{
    NSArray *volumes = nil;
    NSString *target = nil;
    BOOL targetStatus = NO;
	
    [runtimePolicyBannerTextView setString:@""];
    
    if(aConfig != nil)
    {		
        if(([kDSTUDIO_TASK_TARGET_TYPE_LAST_SELECTED caseInsensitiveCompare:[aConfig objectForKey:kDSTUDIO_TASK_KEY_TARGET_TYPE]] == NSOrderedSame) && ([dSRuntimeServices lastSelectedTarget] !=  nil))
			target = [self runtimeFilteredTarget:[dSRuntimeServices lastSelectedTarget]];
        else if(([kDSTUDIO_TASK_TARGET_TYPE_LAST_RESTORED caseInsensitiveCompare:[aConfig objectForKey:kDSTUDIO_TASK_KEY_TARGET_TYPE]] == NSOrderedSame) && ([dSRuntimeServices lastRestoredVolume] !=  nil))
			target = [self runtimeFilteredTarget:[dSRuntimeServices lastRestoredVolume]];
        else
            target = [self runtimeFilteredTarget:[aConfig objectForKey:kDSTUDIO_TASK_KEY_TARGET_NAME]];
        
        // get policy banner content
        if([aConfig objectForKey:kDSTUDIO_TASK_KEY_POLICY_BANNER_CONTENT] != nil)
        {
            [runtimePolicyBannerTextView replaceCharactersInRange:NSMakeRange(0, [[runtimePolicyBannerTextView string] length])
                                                        withRTF:[aConfig objectForKey:kDSTUDIO_TASK_KEY_POLICY_BANNER_CONTENT]];
        }
        
		runtimeAutomate = ([(NSString*)@"YES" caseInsensitiveCompare:[aConfig objectForKey:kDSTUDIO_TASK_KEY_AUTOMATE]] == NSOrderedSame);
    }
	else
	{
        runtimeAutomate = NO;
	}
    
    if(target != nil)
    {
        [runtimeTargetPopUpButton removeAllItems];
        [runtimeTargetPopUpButton addItemWithTitle:target];
        targetStatus = YES;
    }
    else
    {
        // search available target volumes
        volumes = [[dSHostServices class] hostListOfVolumes:([dSRuntimeServices netBootContext] == NO)];
        [runtimeTargetPopUpButton removeAllItems];
        if((volumes == nil) || ([volumes count] < 1))
            [runtimeTargetPopUpButton addItemWithTitle:@"-"];
        else {
            [runtimeTargetPopUpButton addItemsWithTitles:volumes];
            if([runtimeTargetPopUpButton numberOfItems] == 0)
                [runtimeTargetPopUpButton addItemWithTitle:@"-"];
            else
				targetStatus = YES;
        }
    }
	
    [runtimeTargetPopUpButton setEnabled:(runtimeAutomate == NO)];
    [runtimePolicyBannerTextView setEditable:(runtimeAutomate == NO)];
    
    [dSRuntimeServices setReloadButtonEnabled:NO];
    [dSRuntimeServices setBackButtonEnabled:(runtimeAutomate == NO)];
    [dSRuntimeServices setProceedButtonEnabled:((targetStatus == YES) && (runtimeAutomate == NO))];
    [dSRuntimeServices setSkipButtonEnabled:(runtimeAutomate == NO)];
    [dSRuntimeServices syncButtonsStatus];
}

- (void) revert
{
}

- (void) proceed
{
    NSDate *startedAt = [NSDate date];
    NSMutableDictionary *taskInfos = [NSMutableDictionary dictionary];
    
	NSString *target = [runtimeTargetPopUpButton titleOfSelectedItem];

    NSLog(@"Example task action:");

	if((target == nil) || ([(NSString*)@"-" compare:target] == NSOrderedSame))
	{
		if(runtimeAutomate == YES)
		{
			NSLog(@"Invalid target volume.");
			[[NSNotificationCenter defaultCenter] postNotificationName:kDSTUDIO_TASK_FAILED_NOTIFICATION 
																object:nil 
															  userInfo:[NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithFloat:0.0], @"duration",
																		mDSTUDIO_LOC(@"The target volume was not found"), @"error", nil]];
		}
		else
		{
			NSBeginCriticalAlertSheet(mDSTUDIO_LOC(@"Invalid target volume!"), 
									  mDSTUDIO_LOC(@"OK"), nil, nil, 
									  [runtimeView window], nil, nil, nil, [runtimeView window], 
									  mDSTUDIO_LOC(@"The target volume was not found. Please check your workflow."));
		}
		return;
	}
	
    // then proceed the task
    [runtimeTargetPopUpButton setEnabled:NO];
    [runtimePolicyBannerTextView setEditable:NO];

	[dSRuntimeServices setReloadButtonEnabled:NO];
	[dSRuntimeServices setBackButtonEnabled:NO];
	[dSRuntimeServices setProceedButtonEnabled:NO];
	[dSRuntimeServices setSkipButtonEnabled:NO];
	[dSRuntimeServices syncButtonsStatus];
	    
    NS_DURING
    {
        NSLog(@"Installing policy banner file");
            
        [dSRuntimeServices resetStatusPane];
        [dSRuntimeServices setStatusMessage:mDSTUDIO_LOC(@"Installing policy banner file")];
        [dSRuntimeServices animateCurrentTask];

        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^() {
            BOOL rc = NO;
            NSMutableString *policyBannerFile = [NSMutableString stringWithFormat:@"/Volumes/%@/Library/Security", target];
            
            if([[NSFileManager defaultManager] fileExistsAtPath:policyBannerFile] == YES)
            {
                NSData *policyBannerContent = [runtimePolicyBannerTextView RTFFromRange:NSMakeRange(0, [[runtimePolicyBannerTextView string] length])];
                if((policyBannerContent != nil) && ([policyBannerContent length] > 0))
                {
                    [policyBannerFile appendString:@"/PolicyBanner.rtf"];
                    rc = [policyBannerContent writeToFile:policyBannerFile atomically:YES];
                    [[NSFileManager defaultManager] setAttributes:[NSDictionary dictionaryWithObject:[NSNumber numberWithInt:0664]
                                                                                              forKey:NSFilePosixPermissions]
                                                     ofItemAtPath:policyBannerFile error:nil];
                }
            }

            [dSRuntimeServices setLastSelectedTarget:target];
            [dSRuntimeServices resetStatusPane];

            [taskInfos setValue:[NSNumber numberWithFloat:(-[startedAt timeIntervalSinceNow] / 60.)] forKey:@"duration"];
            if(rc == YES) {
                NSLog(@"Example task configuration successful (elapsed time: %.2f minutes)", [(NSNumber*)[taskInfos objectForKey:@"duration"] floatValue]);
                [[NSNotificationCenter defaultCenter] postNotificationName:kDSTUDIO_TASK_COMPLETED_NOTIFICATION object:nil userInfo:taskInfos];
            }
            else {
                NSLog(@"Example task configuration failure (elapsed time: %.2f minutes)", [(NSNumber*)[taskInfos objectForKey:@"duration"] floatValue]);
                [[NSNotificationCenter defaultCenter] postNotificationName:kDSTUDIO_TASK_FAILED_NOTIFICATION object:nil userInfo:taskInfos];
            }
        });
    }
    NS_HANDLER
    {
        [dSRuntimeServices resetStatusPane];
        NSLog(@"Task failure (elapsed time: %.2f minutes)", [(NSNumber*)[taskInfos objectForKey:@"duration"] floatValue]);
        [[NSNotificationCenter defaultCenter] postNotificationName:kDSTUDIO_TASK_FAILED_NOTIFICATION object:nil userInfo:taskInfos];
    }
    NS_ENDHANDLER
}

- (void) skip
{
    NSLog(@"Example task skipped");
    [[NSNotificationCenter defaultCenter] postNotificationName:kDSTUDIO_TASK_COMPLETED_NOTIFICATION object:nil];
}

@end
